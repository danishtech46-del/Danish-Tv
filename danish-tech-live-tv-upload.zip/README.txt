Danish Tech Live TV upload package.

Files: index.html and logo.png.
The supplied HTML originally referenced style.css and script.js; those source files were not included in the uploaded material, so they are not invented here.
